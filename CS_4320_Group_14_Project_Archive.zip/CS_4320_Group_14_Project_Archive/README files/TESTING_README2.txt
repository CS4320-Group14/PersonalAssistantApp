UNIT TESTING


*  Methods or entire classes would be copied to the java folder per src > test > java


*  Unit tests can be run in Android Studio by applying "@Test" directly above methods
   of interest. 
   
   
*  Results can be seen in the lower left corner withint he Run tab/window


*  The option to export and import test results preside in two buttons on the top right 
   corner of the Run window/tab (once again by default in the lower left corner)
   
   
*  Under Run in the main navigation bar there is another option to import test results


