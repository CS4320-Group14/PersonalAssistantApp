PROGRAM CHANGES++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

Key differences between application from Demo 1 and Demo 2:

1. Functionality of database connection properly established:

	Connection to the JSON tree database provided by the Google Firebase API involved something of a
	learning curve. As such extensive testing of individual function connections was required to discern 
	proper connection to the JSON tree which itself simplistic yet unconventional. 

2. Fuller realization of the user interface:
	
	Previously GUI pages or "activities" per Android Studio IDE and respective buttons, were established but 
	lacked functionality. Since the last demo, traversal among activities/GUI elements was enabled and core
	functions implemented with the buttons. 

3. Completion functionality concerning user interaction:

	Per the completion of the Query and Recommendation classes, interaction with the user and the application
	has been enabled.Unfortunately this communication is suppose to be accompanied by concurrency per the 
	potential for both to occur at the same time. This part was not achieved as of this demo. However, the 
	classes have functions that output a random array of recommendations and a pop-up that gathers information
	the user productivity which can be transmitted to the database. 

4. Completion of user database update function:

	Now a component of the query class, the updateWorkMetric function now has the capability to connect to and make 
	changes to the database. However it is not capable of working on a predetermined timer. The android application 
	was very sensitive to use of time as an element and was prone to crash when accessing any time related data. The 
	issues with time was discovered as the application experienced extensive modular testing. This proved disruptive 
	as time is an important aspect to both the application's data and functionality. 

5. Cancellation of Google sync feature:

	Due to issues with time and lacking performance from some members of our team, the Google sync feature was cut. 
	Among our features it was seen as being more extraneous. 
	
PROGRAM RUN PROCEDURE+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

* The folder named Productivity_Assistant holds the Query and Recommendation section as well as 
  GUI for the opening page and for the tracker and schedule pages. 
  
* Path for main java files in Productivity_Assistant:
   Productivity_Assistant>app>src>main>java>com>productivityassistant>group14>productivityassistant

* There isn't much in the way of code in the Schedule and HistogramChart folders. 

* The HistogramChart folder consists of current code for the Tracker feature of the application.

* Schedule folder consists of current "code" (maybe assets?) for Schedule feature

* Program can be run in Android Studio via the "Run..." or "Run 'my application'" option
  under Run in the main navigation bar

* Program should work for most emulations. For our own testing we used a Nexus 5 emulations

* Parts of our code were experiencing issues with the emulation run and are in the process of
  unit testing to better cypher issues. 
  
* Dummy values for day (which requires a string) and hour (which takes an integer) can be inputted
  for relevant methods in CurrentTime and DBMS for a disconnected run. 
  
* DBMS methods would also need an array of dummy values for seperate testing. 