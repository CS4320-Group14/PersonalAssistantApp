DATA COLLECTION

Database 

The database is a JSON Tree with 7 main branches for each day of the week followed by 24 leaf nodes
for each branch representing the hours in military time (0-23). These branches and leaf nodes are 
referred to children to the main root.

Collection

Data can be collected a number of ways from the tree. The chosen method for this application is to 
access particular child nodes through a database object called Datasnapshot provided by Firebase.

Example

int workMetric = dataSnapshot.child(day).child(hour).getValue(Integer.class);
