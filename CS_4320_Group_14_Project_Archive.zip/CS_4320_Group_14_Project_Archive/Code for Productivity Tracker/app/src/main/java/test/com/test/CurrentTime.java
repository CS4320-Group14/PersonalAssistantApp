package test.com.test;

import android.os.Build;
import android.support.annotation.RequiresApi;

import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;
import java.time.*;




public class CurrentTime
{



    @RequiresApi(api = Build.VERSION_CODES.O)
    public String getHour()
    {
        ZoneId centralTime = ZoneId.of("America/Chicago");
        DateTimeFormatter hourFormat = DateTimeFormatter.ofPattern("H");
        LocalTime time = LocalTime.now(centralTime);
        String formattedTime = time.format(hourFormat);
        Date date = new Date();

        String s_Hour = formattedTime;
        return s_Hour;
    }

    public String getDay()
    {
        Calendar calendar = Calendar.getInstance();
        Integer dayOfWeek = calendar.get(Calendar.DAY_OF_WEEK);
        String currentDay = "";
        String weekdays[] = {"sunday","monday","tuesday","wednesday","thursday","friday","saturday"};
        for(int i = 0;i<6;i++)
        {
            if(dayOfWeek == i)
            {
                currentDay = weekdays[i];

            }
        }
        return currentDay;
    }
}
