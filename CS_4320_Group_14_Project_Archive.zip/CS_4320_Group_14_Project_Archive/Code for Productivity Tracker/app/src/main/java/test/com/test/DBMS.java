package test.com.test;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class DBMS extends CurrentTime
{
    CurrentTime time;
    String day = time.getDay();
    FirebaseDatabase database = FirebaseDatabase.getInstance();


    //final DatabaseReference databaseReference = database.getReference();



    //hour and day will need to be assigned values from timestamp information before being passed to methods
    final String hour = "";


    //retrieve hours from day tables////////////////////////////////////////////////////////
    public int getWorkMetric(DataSnapshot dataSnapshot, String day, String hour)
    {
        Integer workMetric = dataSnapshot.child(day).child(hour).getValue(Integer.class);
        return workMetric;
    }


    //set work metric for particular day hour///////////////////////////////////////

    public void updateWorkMetric(DataSnapshot dataSnapshot, String day, String hour)
    {
        hour = this.hour;
        final DatabaseReference dRef = database.getReference(day);
        Integer  workMetric = dataSnapshot.child(day).child(hour).getValue(Integer.class);
        workMetric += 1;
        String s_WorkMetric = Integer.toString(workMetric);
        dRef.child(hour).setValue(50);
    }


    public void clearWorkMetric(DataSnapshot dataSnapshot, String day, String hour, DatabaseReference dRef)
    {
        int workMetric = dataSnapshot.child(day).child(hour).getValue(Integer.class);
        workMetric = 0;
        dRef.child(day).child(hour).setValue(workMetric);
    }


}