package test.com.test;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

@RequiresApi(api = Build.VERSION_CODES.O)
public class MainActivity extends AppCompatActivity {
    CurrentTime time;
    DBMS dbms;
    DataSnapshot dataSnapshot;
    //Used to load the 'native-lib' library on application startup.
    static {
        System.loadLibrary("native-lib");
    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Example of a call to a native method
        TextView tv = (TextView) findViewById(R.id.sample_text);
        tv.setText("Productivity Assistant");

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        final DatabaseReference dRef = database.getReference("sunday");

        Button trackerButton = (Button)findViewById(R.id.trackerButton);
        trackerButton.setOnClickListener(
                new View.OnClickListener(){

                    @Override
                    public void onClick(View v)
                    {

                       // dbms.updateWorkMetric("sunday","11");
                        Intent startTrackerIntent = new Intent(getApplicationContext(),ProductivityTracker.class);
                        startActivity(startTrackerIntent);
                       // String hour = time.getHour();
                       // String day = time.getDay();

                        dRef.child("10").setValue(1);
                    }
                }
        );

        Button scheduleButton = (Button)findViewById(R.id.scheduleButton);
        scheduleButton.setOnClickListener(
                new View.OnClickListener(){
                    @Override
                    public void onClick(View v)
                    {
                        Intent startScheduleIntent = new Intent(getApplicationContext(),Schedule.class);
                        startActivity(startScheduleIntent);
                    }
                }
        );

        Button queryButton = (Button)findViewById(R.id.queryButton);
        queryButton.setOnClickListener(
                new View.OnClickListener(){
                    @Override
                    public void onClick(View v)
                    {
               Query query = new Query();
               query.show(getSupportFragmentManager(),"");
                    }
                }
        );

        Button recommendButton = (Button)findViewById(R.id.recommendButton);
        recommendButton.setOnClickListener(
                new View.OnClickListener(){
                    @Override
                    public void onClick(View v)
                    {
                        Recommendation recommendation = new Recommendation();
                        recommendation.show(getSupportFragmentManager(),"");
                    }
                }
        );

        Button averageButton = (Button)findViewById(R.id.averageButton);
        averageButton.setOnClickListener(
                new View.OnClickListener(){
                    @Override
                    public void onClick(View v)
                    {
                        Intent startMetricsIntent = new Intent(getApplicationContext(),WeekMetrics.class);
                        startActivity(startMetricsIntent);
                    }
                }
        );
    }

   // FragmentManager manager = getSupportFragmentManager();
  //  Query query = new Query();
   //                     query.show(manager, "123");

    /**
     * A native method that is implemented by the 'native-lib' native library,
     * which is packaged with this application.
     */
    public native String stringFromJNI();
}
