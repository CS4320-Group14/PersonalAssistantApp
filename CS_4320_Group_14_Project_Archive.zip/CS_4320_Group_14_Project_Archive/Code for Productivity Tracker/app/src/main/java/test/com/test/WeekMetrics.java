package test.com.test;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.widget.TextView;

public class WeekMetrics extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_week_metrics);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

    Analysis analysis = new Analysis();
    double average = 0;
    double updatedAverage = analysis.findAverage(average);
    String averageText = Double.toString(updatedAverage);
        TextView averageView = (TextView) findViewById(R.id.averageView);
        averageView.setText(averageText);
            }

    }


