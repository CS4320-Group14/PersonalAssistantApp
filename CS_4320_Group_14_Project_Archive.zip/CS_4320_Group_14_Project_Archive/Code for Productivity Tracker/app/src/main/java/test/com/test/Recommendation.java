package test.com.test;

import android.app.Dialog;
import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import android.support.v7.app.AlertDialog;

import java.util.Random;

public class Recommendation extends DialogFragment
{
    String recommendationArray[] = {"Now is a good time do some work!","I'd Recommend doing some homework now.",
    "Time to get some work done","Would you be willing to get some tasks done now?",
            "Please take this time to finish some tasks."};

    Random rand = new Random();


    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState)
    {
        int randNum = rand.nextInt(4);
        String recommendation = "";
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        for(int i = 0;i<4;i++)
        {
            if(i == randNum)
            {
                recommendation = recommendationArray[i];
            }
        }
        builder.setMessage(recommendation)
              ;
        return builder.create();
    }
}
